"""
Audio Fingerprinting Module
Implements a Shazam-inspired combinatorial hashing algorithm.
Generates robust fingerprints from spectral peaks that are invariant
to noise, pitch shifts, and tempo changes.
"""
import numpy as np
from typing import List, Tuple
import config


class FingerprintGenerator:
    """
    Generates audio fingerprints using combinatorial hashing of spectral peaks.

    Algorithm Overview:
    1. Detect spectral peaks (constellation map)
    2. For each anchor peak, pair with peaks in a target zone
    3. Hash the pair: hash(frequency1, frequency2, time_delta)
    4. Store (hash, anchor_time_offset)
    """

    def __init__(self, fan_value: int = config.FAN_VALUE,
                 min_time_delta: int = config.MIN_TIME_DELTA,
                 max_time_delta: int = config.MAX_TIME_DELTA):
        self.fan_value = fan_value
        self.min_time_delta = min_time_delta
        self.max_time_delta = max_time_delta

    def generate_fingerprints(self, peaks: np.ndarray) -> List[Tuple[int, int]]:
        """
        Generate combinatorial hashes from spectral peaks.

        Args:
            peaks: Array of [freq_bin, time_frame] coordinates

        Returns:
            List of (hash_value, anchor_time_offset) tuples
        """
        if len(peaks) == 0:
            return []

        fingerprints = []

        # Sort peaks by time to ensure consistent ordering
        peaks = peaks[np.argsort(peaks[:, 1])]

        for i in range(len(peaks)):
            anchor_freq = int(peaks[i, 0])
            anchor_time = int(peaks[i, 1])

            # Pair anchor with next 'fan_value' peaks
            for j in range(1, self.fan_value + 1):
                if i + j >= len(peaks):
                    break

                target_freq = int(peaks[i + j, 0])
                target_time = int(peaks[i + j, 1])
                time_delta = target_time - anchor_time

                # Only use pairs within valid time window
                if self.min_time_delta <= time_delta <= self.max_time_delta:
                    # Create deterministic hash from frequency pair and time delta
                    # Using a simple but effective hash combination
                    hash_value = self._hash_pair(anchor_freq, target_freq, time_delta)
                    fingerprints.append((hash_value, anchor_time))

        return fingerprints

    def _hash_pair(self, f1: int, f2: int, dt: int) -> int:
        """
        Create a deterministic hash from a peak pair.

        Args:
            f1: Anchor frequency bin
            f2: Target frequency bin  
            dt: Time delta between peaks

        Returns:
            32-bit unsigned integer hash
        """
        # Combine values using a hash function that spreads bits well
        h = (f1 * 73856093) ^ (f2 * 19349663) ^ (dt * 83492791)
        return h & 0xFFFFFFFF  # Ensure 32-bit unsigned


class QueryFingerprinter:
    """
    Generates fingerprints from query audio (humming/short clip).
    Uses the same algorithm as the database for consistent matching.
    """

    def __init__(self, processor, fingerprint_gen: FingerprintGenerator):
        self.processor = processor
        self.fingerprint_gen = fingerprint_gen

    def fingerprint_audio(self, filepath: str, preprocess: bool = True) -> Tuple[List[Tuple[int, int]], np.ndarray]:
        """
        Process an audio file and generate fingerprints.
        For query audio (microphone recordings), applies noise reduction
        and enhancement preprocessing before peak detection.

        Args:
            filepath: Path to audio file
            preprocess: If True, apply noise reduction pipeline (default for queries)

        Returns:
            Tuple of (fingerprints, processed_audio)
        """
        y, sr = self.processor.load_audio(filepath)

        if preprocess:
            y = self.processor.preprocess_query(y)

        peaks = self.processor.get_spectral_peaks(y, query_mode=preprocess)
        fingerprints = self.fingerprint_gen.generate_fingerprints(peaks)
        return fingerprints, y

    def fingerprint_array(self, audio_array: np.ndarray, sr: int = config.SAMPLE_RATE, preprocess: bool = True) -> List[Tuple[int, int]]:
        """
        Generate fingerprints directly from audio array (for live recording).
        Applies noise reduction preprocessing for microphone input.

        Args:
            audio_array: Audio time series
            sr: Sample rate
            preprocess: If True, apply noise reduction pipeline

        Returns:
            List of fingerprint tuples
        """
        import librosa

        # Resample if necessary
        if sr != self.processor.sr:
            audio_array = librosa.resample(audio_array, orig_sr=sr, target_sr=self.processor.sr)

        if preprocess:
            audio_array = self.processor.preprocess_query(audio_array)

        peaks = self.processor.get_spectral_peaks(audio_array, query_mode=preprocess)
        return self.fingerprint_gen.generate_fingerprints(peaks)
