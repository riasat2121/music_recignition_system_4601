"""
Audio Recorder Module
Handles real-time microphone recording for live query input.
Supports recording from default system microphone with configurable duration.
"""
import numpy as np
import wave
import os
import tempfile
import config


class AudioRecorder:
    """
    Records audio from microphone input.

    Uses sounddevice for cross-platform audio capture.
    Falls back to wave/pyaudio if sounddevice is not available.
    """

    def __init__(self, sr: int = config.SAMPLE_RATE, 
                 channels: int = config.RECORD_CHANNELS,
                 duration: int = config.RECORD_DURATION):
        self.sr = sr
        self.channels = channels
        self.duration = duration
        self._sd = None
        self._try_import_sounddevice()

    def _try_import_sounddevice(self):
        """Try to import sounddevice; handle gracefully if unavailable."""
        try:
            import sounddevice as sd
            self._sd = sd
        except ImportError:
            self._sd = None

    def is_available(self) -> bool:
        """Check if audio recording is available on this system."""
        return self._sd is not None

    def record(self, duration: int = None, save_path: str = None) -> str:
        """
        Record audio from microphone.

        Args:
            duration: Recording duration in seconds (default from config)
            save_path: Path to save WAV file (default: temp file)

        Returns:
            Path to saved audio file
        """
        if not self.is_available():
            raise RuntimeError(
                "sounddevice not installed. Install with: pip install sounddevice"
            )

        duration = duration or self.duration

        if save_path is None:
            save_path = os.path.join(config.TEMP_DIR, f"query_{os.getpid()}.wav")

        print(f"Recording {duration} seconds of audio...")

        # Record audio
        recording = self._sd.rec(
            int(duration * self.sr),
            samplerate=self.sr,
            channels=self.channels,
            dtype=config.RECORD_DTYPE
        )
        self._sd.wait()  # Wait until recording is finished

        # Force mono: sounddevice may return (samples, channels) even with channels=1
        recording = np.squeeze(recording)
        if recording.ndim == 2:
            recording = np.mean(recording, axis=1)

        # Convert float32 to int16 for WAV format
        if recording.dtype == np.float32:
            recording = np.int16(recording * 32767)

        with wave.open(save_path, 'wb') as wf:
            wf.setnchannels(1)  # Always save as mono
            wf.setsampwidth(2)  # 16-bit
            wf.setframerate(self.sr)
            wf.writeframes(recording.tobytes())

        print(f"Saved recording to: {save_path}")
        return save_path

    def record_to_array(self, duration: int = None) -> np.ndarray:
        """
        Record audio and return as numpy array.

        Args:
            duration: Recording duration in seconds

        Returns:
            Audio time series as numpy array
        """
        if not self.is_available():
            raise RuntimeError("sounddevice not installed.")

        duration = duration or self.duration
        recording = self._sd.rec(
            int(duration * self.sr),
            samplerate=self.sr,
            channels=self.channels,
            dtype=config.RECORD_DTYPE
        )
        self._sd.wait()
        recording = np.squeeze(recording)
        if recording.ndim == 2:
            recording = np.mean(recording, axis=1)
        return recording
