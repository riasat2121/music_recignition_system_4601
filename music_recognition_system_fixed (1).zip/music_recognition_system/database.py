"""
Database Module
Manages SQLite database for song metadata, fingerprints, and feature vectors.
Optimized for fast hash-based lookups using indexing.
"""
import sqlite3
import pickle
import numpy as np
from typing import List, Tuple, Optional, Dict
from contextlib import contextmanager
import config


class SongDatabase:
    """
    SQLite-based database for storing song information and fingerprints.

    Schema:
    - songs: id, title, artist, filepath, duration, tempo, features_blob
    - fingerprints: hash_value, song_id, time_offset
    """

    def __init__(self, db_path: str = config.DB_PATH):
        self.db_path = db_path
        self._init_db()

    @contextmanager
    def _get_connection(self):
        """Context manager for database connections."""
        conn = sqlite3.connect(self.db_path)
        conn.execute("PRAGMA journal_mode=WAL")  # Better concurrency
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()

    def _init_db(self):
        """Initialize database tables and indexes."""
        with self._get_connection() as conn:
            # Songs table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS songs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    artist TEXT,
                    filepath TEXT UNIQUE NOT NULL,
                    duration REAL,
                    tempo REAL,
                    features BLOB,
                    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Fingerprints table - optimized for hash lookups
            conn.execute("""
                CREATE TABLE IF NOT EXISTS fingerprints (
                    hash_value INTEGER NOT NULL,
                    song_id INTEGER NOT NULL,
                    time_offset INTEGER NOT NULL,
                    FOREIGN KEY (song_id) REFERENCES songs(id) ON DELETE CASCADE
                )
            """)

            # Indexes for performance
            conn.execute("CREATE INDEX IF NOT EXISTS idx_hash ON fingerprints(hash_value)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_song ON fingerprints(song_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_title ON songs(title)")

    def add_song(self, title: str, artist: str, filepath: str, 
                 duration: float, tempo: float, features: Dict,
                 fingerprints: List[Tuple[int, int]]) -> int:
        """
        Add a new song with its fingerprints to the database.

        Args:
            title: Song title
            artist: Artist name
            filepath: Path to audio file
            duration: Duration in seconds
            tempo: Tempo in BPM
            features: Feature vector dictionary
            fingerprints: List of (hash, time_offset) tuples

        Returns:
            song_id of the inserted song
        """
        # Defensive: ensure native Python types for SQLite compatibility
        duration = float(duration) if duration is not None else 0.0
        tempo = float(tempo) if tempo is not None else 0.0

        with self._get_connection() as conn:
            # Insert song metadata
            cursor = conn.execute(
                "INSERT INTO songs (title, artist, filepath, duration, tempo, features) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (title, artist, filepath, duration, tempo, pickle.dumps(features))
            )
            song_id = cursor.lastrowid

            # Bulk insert fingerprints
            fingerprint_data = [(h, song_id, t) for h, t in fingerprints]
            conn.executemany(
                "INSERT INTO fingerprints (hash_value, song_id, time_offset) VALUES (?, ?, ?)",
                fingerprint_data
            )

            return song_id

    def lookup_hashes(self, hashes: List[int]) -> List[Tuple[int, int, int]]:
        """
        Look up multiple hashes in the database.

        Batches the lookup because SQLite caps the number of '?' parameters
        allowed in a single statement (often as low as 999 depending on the
        platform/build). With dense fingerprinting a query can easily produce
        tens of thousands of hashes, so a single "IN (...)" query for all of
        them can raise "too many SQL variables". Chunking avoids that
        regardless of the local SQLite build's limit.

        Args:
            hashes: List of hash values to look up

        Returns:
            List of (hash_value, song_id, time_offset) tuples
        """
        if not hashes:
            return []

        results = []
        with self._get_connection() as conn:
            for i in range(0, len(hashes), config.SQL_LOOKUP_BATCH_SIZE):
                batch = hashes[i:i + config.SQL_LOOKUP_BATCH_SIZE]
                placeholders = ','.join('?' * len(batch))
                query = f"SELECT hash_value, song_id, time_offset FROM fingerprints WHERE hash_value IN ({placeholders})"
                cursor = conn.execute(query, batch)
                results.extend(cursor.fetchall())
        return results

    def get_song_by_id(self, song_id: int) -> Optional[Dict]:
        """Retrieve song metadata by ID."""
        with self._get_connection() as conn:
            cursor = conn.execute(
                "SELECT id, title, artist, filepath, duration, tempo, features FROM songs WHERE id = ?",
                (song_id,)
            )
            row = cursor.fetchone()
            if row:
                return {
                    'id': row[0],
                    'title': row[1],
                    'artist': row[2],
                    'filepath': row[3],
                    'duration': row[4],
                    'tempo': row[5],
                    'features': pickle.loads(row[6]) if row[6] else None
                }
            return None

    def get_all_songs(self) -> List[Dict]:
        """Retrieve all songs with their features."""
        with self._get_connection() as conn:
            cursor = conn.execute(
                "SELECT id, title, artist, filepath, duration, tempo, features FROM songs ORDER BY title"
            )
            songs = []
            for row in cursor.fetchall():
                songs.append({
                    'id': row[0],
                    'title': row[1],
                    'artist': row[2],
                    'filepath': row[3],
                    'duration': row[4],
                    'tempo': row[5],
                    'features': pickle.loads(row[6]) if row[6] else None
                })
            return songs

    def get_song_count(self) -> int:
        """Return total number of songs in database."""
        with self._get_connection() as conn:
            cursor = conn.execute("SELECT COUNT(*) FROM songs")
            return cursor.fetchone()[0]

    def delete_song(self, song_id: int):
        """Remove a song and its fingerprints from the database."""
        with self._get_connection() as conn:
            conn.execute("DELETE FROM songs WHERE id = ?", (song_id,))

    def clear_database(self):
        """Clear all songs and fingerprints."""
        with self._get_connection() as conn:
            conn.execute("DELETE FROM fingerprints")
            conn.execute("DELETE FROM songs")
