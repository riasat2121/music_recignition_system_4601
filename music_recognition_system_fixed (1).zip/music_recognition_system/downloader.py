"""
YouTube Playlist Downloader Module
Downloads audio from YouTube playlists using yt-dlp.
Extracts metadata (title, artist) and converts to WAV format for processing.
"""
import os
import re
from typing import List, Callable, Optional
import config


class YouTubeDownloader:
    """
    Downloads audio from YouTube playlists/channels.

    Uses yt-dlp Python API for robust downloading with progress callbacks.
    Automatically extracts audio to WAV format suitable for fingerprinting.
    """

    def __init__(self, output_dir: str = config.AUDIO_DIR,
                 max_duration: int = 300):  # 5 min max per song
        self.output_dir = output_dir
        self.max_duration = max_duration
        self._ytdlp = None
        self._try_import_ytdlp()

    def _try_import_ytdlp(self):
        """Try to import yt_dlp; handle gracefully if unavailable."""
        try:
            import yt_dlp
            self._ytdlp = yt_dlp
        except ImportError:
            self._ytdlp = None

    def is_available(self) -> bool:
        """Check if yt-dlp is installed."""
        return self._ytdlp is not None

    def download_playlist(self, playlist_url: str, 
                         progress_callback: Optional[Callable] = None,
                         max_songs: Optional[int] = None) -> List[dict]:
        """
        Download all songs from a YouTube playlist.

        Args:
            playlist_url: YouTube playlist URL
            progress_callback: Function(info_dict) called on progress
            max_songs: Limit number of songs to download (None for all)

        Returns:
            List of dicts with {title, artist, filepath, duration}
        """
        if not self.is_available():
            raise RuntimeError(
                "yt-dlp not installed. Install with: pip install yt-dlp"
            )

        os.makedirs(self.output_dir, exist_ok=True)
        downloaded = []

        def hook(d):
            if d['status'] == 'finished' and progress_callback:
                progress_callback(d.get('info_dict', {}))

        ydl_opts = {
            'format': 'bestaudio/best',
            'outtmpl': os.path.join(self.output_dir, '%(title)s.%(ext)s'),
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'wav',
                'preferredquality': '192',
            }],
            'max_filesize': 50 * 1024 * 1024,  # 50MB max
            'match_filter': self._duration_filter,
            'quiet': True,
            'no_warnings': True,
            'progress_hooks': [hook],
        }

        if max_songs:
            ydl_opts['playlistend'] = max_songs

        with self._ytdlp.YoutubeDL(ydl_opts) as ydl:
            try:
                info = ydl.extract_info(playlist_url, download=True)

                # Handle both playlist and single video
                entries = info.get('entries', [info])

                for entry in entries:
                    if not entry:
                        continue

                    title = entry.get('title', 'Unknown')
                    uploader = entry.get('uploader', 'Unknown Artist')
                    duration = entry.get('duration', 0)

                    # Find the downloaded WAV file
                    base_name = ydl.prepare_filename(entry)
                    wav_path = os.path.splitext(base_name)[0] + '.wav'

                    if os.path.exists(wav_path):
                        downloaded.append({
                            'title': title,
                            'artist': uploader,
                            'filepath': wav_path,
                            'duration': duration
                        })

            except Exception as e:
                print(f"Download error: {e}")

        return downloaded

    def _duration_filter(self, info_dict):
        """Filter out videos that are too long."""
        duration = info_dict.get('duration')
        if duration and duration > self.max_duration:
            return f"Video too long ({duration}s > {self.max_duration}s)"
        return None

    @staticmethod
    def sanitize_filename(name: str) -> str:
        """Remove invalid characters from filenames."""
        return re.sub(r'[<>:"/\\|?*]', '_', name)
