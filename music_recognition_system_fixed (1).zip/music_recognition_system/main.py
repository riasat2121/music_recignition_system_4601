"""
Real-Time Audio Pattern Recognition System
Entry point for the complete music identification application.

Usage:
    python main.py          # Launch GUI mode
    python main.py --cli    # Launch command-line mode
"""

import argparse
import sys
import os

# Ensure project modules are importable
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import config
from gui import main as gui_main
from audio_processor import AudioProcessor
from fingerprint import FingerprintGenerator, QueryFingerprinter
from database import SongDatabase
from matcher import MatchingEngine
from recommender import RecommendationEngine


def cli_mode():
    """Command-line interface for testing without GUI."""
    print("=" * 60)
    print("Real-Time Audio Pattern Recognition System - CLI Mode")
    print("=" * 60)

    processor = AudioProcessor()
    fp_gen = FingerprintGenerator()
    db = SongDatabase()
    matcher = MatchingEngine(db, fp_gen, processor)
    recommender = RecommendationEngine(db)

    print(f"\nDatabase contains {db.get_song_count()} songs.")

    while True:
        print("\nOptions:")
        print("1. Index a song file")
        print("2. Identify a song from file")
        print("3. Show all indexed songs")
        print("4. Get recommendations for a song ID")
        print("5. Exit")

        choice = input("\nSelect option: ").strip()

        if choice == "1":
            path = input("Enter audio file path: ").strip()
            if not os.path.exists(path):
                print("File not found.")
                continue

            print("Processing...")
            try:
                # Load the FULL song, not just a short query-length clip -
                # otherwise only the first ~30s gets fingerprinted and
                # anything recorded later in the song can never match.
                y, sr = processor.load_audio(path, duration=config.DB_INDEX_MAX_DURATION)
                features = processor.get_feature_vector(y)
                peaks = processor.get_spectral_peaks(y)
                fingerprints = fp_gen.generate_fingerprints(peaks)

                title = input("Song title: ").strip()
                artist = input("Artist: ").strip() or "Unknown"

                song_id = db.add_song(
                    title, artist, path, len(y)/sr, 
                    features['tempo'], features, fingerprints
                )
                print(f"Indexed successfully (ID: {song_id})")
            except Exception as e:
                print(f"Error: {e}")

        elif choice == "2":
            path = input("Enter query audio path: ").strip()
            if not os.path.exists(path):
                print("File not found.")
                continue

            print("Analyzing...")
            try:
                query_fp, y = QueryFingerprinter(processor, fp_gen).fingerprint_audio(path)
                query_features = processor.get_feature_vector(y)
                results = matcher.identify(query_fp, query_features, top_k=3)

                if results:
                    print(f"\n🎵 Match: {results[0]['title']} by {results[0]['artist']}")
                    print(f"   Confidence: {results[0]['confidence']}%")

                    recs = recommender.get_recommendations(results[0]['song_id'])
                    if recs:
                        print("\nSimilar songs:")
                        for r in recs:
                            print(f"   - {r['title']} ({r['similarity_score']}%)")
                else:
                    print("No match found.")
            except Exception as e:
                print(f"Error: {e}")

        elif choice == "3":
            songs = db.get_all_songs()
            for s in songs:
                print(f"ID {s['id']}: {s['title']} by {s['artist']}")

        elif choice == "4":
            sid = input("Enter song ID: ").strip()
            try:
                recs = recommender.get_recommendations(int(sid))
                for r in recs:
                    print(f"   - {r['title']} by {r['artist']} ({r['similarity_score']}%)")
            except Exception as e:
                print(f"Error: {e}")

        elif choice == "5":
            print("Goodbye!")
            break


def main():
    parser = argparse.ArgumentParser(description="Audio Pattern Recognition System")
    parser.add_argument("--cli", action="store_true", help="Run in CLI mode")
    args = parser.parse_args()

    if args.cli:
        cli_mode()
    else:
        gui_main()


if __name__ == "__main__":
    main()
