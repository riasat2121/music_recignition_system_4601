"""
Configuration module for the Music Recognition System.
Contains all tunable parameters for audio processing, fingerprinting,
and database management.
"""
import os

# Base paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
AUDIO_DIR = os.path.join(BASE_DIR, "audio_library")
DB_PATH = os.path.join(BASE_DIR, "songs.db")
TEMP_DIR = os.path.join(BASE_DIR, "temp")

# Create directories if they don't exist
os.makedirs(AUDIO_DIR, exist_ok=True)
os.makedirs(TEMP_DIR, exist_ok=True)

# Audio Processing Parameters
SAMPLE_RATE = 22050      # Hz - standard for music analysis
# NOTE: this used to cap indexing at the first 30 seconds of every song
# (librosa.load(..., duration=ANALYZE_DURATION)). That means any recording
# from later in a song could never match, since those fingerprints were
# never stored at all - not a quality problem, they just don't exist in the
# DB. ANALYZE_DURATION now only applies to short/query clips; the full
# library-indexing path loads the entire file. See DB_INDEX_MAX_DURATION
# below for a safety ceiling on very long files (e.g. accidental podcasts).
ANALYZE_DURATION = 30    # seconds to analyze for query/CLI feature preview use
DB_INDEX_MAX_DURATION = 600  # hard ceiling (10 min) on how much of a library file gets indexed
N_FFT = 2048             # FFT window size
HOP_LENGTH = 512         # Hop length for STFT
N_MFCC = 13              # Number of MFCC coefficients

# Fingerprinting Parameters (Shazam-inspired)
FAN_VALUE = 15           # Number of target peaks per anchor point
MIN_TIME_DELTA = 1       # Minimum time difference between peak pairs (frames)
MAX_TIME_DELTA = 10      # Maximum time difference between peak pairs (frames)
# NOTE: (20,20) was far too large a neighborhood for this spectrogram size and
# produced only ~200 peaks for a whole 30s song - nowhere near enough
# redundancy to survive any real-world difference between query and DB audio.
# A smaller neighborhood yields thousands of peaks, which is what actually
# makes hash-based matching robust to noise.
PEAK_NEIGHBORHOOD_SIZE = (10, 10)  # (freq, time) for local maxima detection
PEAK_AMP_PERCENTILE = 60 # Percentile threshold for peak amplitude
# Peaks are now budgeted per second of audio rather than one fixed total, and
# spread evenly across time (see _select_peaks_with_coverage in
# audio_processor.py). A single fixed TOP_N_PEAKS (e.g. 2500) made sense for
# a 30s clip but badly under-fingerprints a 4-minute song, AND a pure global
# top-N-by-amplitude selection concentrates peaks in the loudest section
# (e.g. the chorus/drop) and leaves quieter sections - verses, bridges,
# outros - with almost no fingerprints. If someone records from one of those
# under-covered sections, it fails to match even though the song IS indexed.
PEAK_TARGET_DENSITY_PER_SEC = 40  # target peaks/sec for DB (library) indexing
TOP_N_PEAKS = 20000       # hard ceiling per song regardless of duration


# Matching Parameters
# Tuned against measured baselines after the peak-density fix: completely
# unrelated audio accumulates only ~2 votes at any single offset by chance,
# while genuine (even moderately degraded) matches reach double digits or
# far higher. 10 keeps a healthy safety margin above the noise floor while
# still accepting weaker real matches. Retune against your own library/mic
# if you see false positives or missed matches in practice.
MATCH_THRESHOLD = 10     # Minimum aligned fingerprints to consider a match
MATCH_CONFIDENCE_SCALE = 100  # Scale factor for confidence percentage

# SQLite caps the number of '?' parameters allowed in a single statement
# (often as low as 999 depending on platform/build). With dense fingerprints
# a query can produce tens of thousands of hashes to look up, so lookups are
# batched at this size to stay well under any such limit.
SQL_LOOKUP_BATCH_SIZE = 500

# Recording Parameters
RECORD_DURATION = 10     # Default recording duration in seconds
RECORD_CHANNELS = 1      # Mono recording
RECORD_DTYPE = "float32"

# Recommendation Parameters
N_RECOMMENDATIONS = 4    # Number of similar songs to recommend
FEATURE_WEIGHT_MFCC = 0.5
FEATURE_WEIGHT_CHROMA = 0.3
FEATURE_WEIGHT_TEMPO = 0.2

# Query Audio Preprocessing (Noise Reduction & Enhancement)
# QUERY_APPLY_SPECTRAL_FILTERS controls the highpass/pre-emphasis/spectral-gate
# steps, which reshape the spectrum before peak detection. Testing showed
# these consistently reduced match rates (even on nearly-clean audio) because
# this algorithm's peak-picking is a hard winner-take-all decision that's
# sensitive to any spectral reshaping. Off by default; flip to True only if
# your recordings have heavy hum/rumble and you've verified it helps more
# than it hurts for your library.
QUERY_APPLY_SPECTRAL_FILTERS = False
QUERY_HIGHPASS_CUTOFF = 80       # Hz - remove low-frequency rumble/hum
QUERY_PREEMPHASIS = 0.97         # Boost high frequencies (speech/music clarity)
QUERY_NOISE_GATE_THRESHOLD = 0.01  # Spectral gating: noise floor multiplier
QUERY_NORMALIZE = True           # Normalize to -1dB peak (safe: doesn't reshape spectrum)
QUERY_TRIM_SILENCE = True        # Trim leading/trailing silence (safe: uniform time shift)
QUERY_TOP_N_PEAKS = 3500         # More peaks for noisy queries (vs DB density)
QUERY_PEAK_AMP_PERCENTILE = 50   # Lower threshold to catch peaks in noise
QUERY_PEAK_TARGET_DENSITY_PER_SEC = 120  # target peaks/sec for query clips (short, so denser)

