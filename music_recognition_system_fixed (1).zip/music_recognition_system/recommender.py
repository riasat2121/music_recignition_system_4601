"""
Recommendation Engine Module
Provides content-based song recommendations using feature vector similarity.
Compares MFCC, chroma, and tempo features to find acoustically similar tracks.
"""
import numpy as np
from typing import List, Dict
import config


class RecommendationEngine:
    """
    Content-based recommendation system.

    Uses a weighted combination of:
    - MFCC similarity (timbre/texture)
    - Chroma similarity (harmonic content)
    - Tempo similarity (rhythm)
    """

    def __init__(self, database):
        self.db = database

    def get_recommendations(self, song_id: int, n: int = config.N_RECOMMENDATIONS) -> List[Dict]:
        """
        Find songs similar to the given song ID.

        Args:
            song_id: ID of the reference song
            n: Number of recommendations to return

        Returns:
            List of recommended song dictionaries with similarity scores
        """
        target_song = self.db.get_song_by_id(song_id)
        if not target_song or not target_song.get('features'):
            return []

        target_features = target_song['features']
        all_songs = self.db.get_all_songs()

        similarities = []

        for song in all_songs:
            if song['id'] == song_id:
                continue
            if not song.get('features'):
                continue

            score = self._compute_similarity(target_features, song['features'])
            similarities.append((song, score))

        # Sort by similarity score descending
        similarities.sort(key=lambda x: x[1], reverse=True)

        recommendations = []
        for song, score in similarities[:n]:
            recommendations.append({
                'song_id': song['id'],
                'title': song['title'],
                'artist': song['artist'],
                'similarity_score': round(score, 2)
            })

        return recommendations

    def _compute_similarity(self, feat1: Dict, feat2: Dict) -> float:
        """
        Compute weighted similarity between two feature dictionaries.
        Returns score between 0 and 100.
        """
        scores = []

        # MFCC similarity (timbre)
        if 'mfcc_mean' in feat1 and 'mfcc_mean' in feat2:
            mfcc_sim = self._cosine_similarity(feat1['mfcc_mean'], feat2['mfcc_mean'])
            scores.append(mfcc_sim * config.FEATURE_WEIGHT_MFCC)

        # Chroma similarity (harmony/melody)
        if 'chroma_mean' in feat1 and 'chroma_mean' in feat2:
            chroma_sim = self._cosine_similarity(feat1['chroma_mean'], feat2['chroma_mean'])
            scores.append(chroma_sim * config.FEATURE_WEIGHT_CHROMA)

        # Tempo similarity (rhythm)
        if 'tempo' in feat1 and 'tempo' in feat2:
            t1, t2 = feat1['tempo'], feat2['tempo']
            # Relative tempo difference
            max_tempo = max(t1, t2, 1)
            tempo_diff = abs(t1 - t2) / max_tempo
            tempo_sim = max(0, 1 - tempo_diff)
            scores.append(tempo_sim * config.FEATURE_WEIGHT_TEMPO)

        if not scores:
            return 0.0

        # Normalize by total weights used
        total_weight = sum([
            config.FEATURE_WEIGHT_MFCC if 'mfcc_mean' in feat1 and 'mfcc_mean' in feat2 else 0,
            config.FEATURE_WEIGHT_CHROMA if 'chroma_mean' in feat1 and 'chroma_mean' in feat2 else 0,
            config.FEATURE_WEIGHT_TEMPO if 'tempo' in feat1 and 'tempo' in feat2 else 0
        ])

        if total_weight == 0:
            return 0.0

        return (sum(scores) / total_weight) * 100

    @staticmethod
    def _cosine_similarity(v1: np.ndarray, v2: np.ndarray) -> float:
        """Compute cosine similarity between two vectors."""
        v1, v2 = np.array(v1), np.array(v2)
        if len(v1) != len(v2):
            return 0.0

        dot = np.dot(v1, v2)
        norm1 = np.linalg.norm(v1)
        norm2 = np.linalg.norm(v2)

        if norm1 == 0 or norm2 == 0:
            return 0.0

        return max(0, dot / (norm1 * norm2))
