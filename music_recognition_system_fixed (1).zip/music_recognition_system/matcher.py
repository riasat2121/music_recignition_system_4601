"""
Matching Engine Module
Implements the core search algorithm that matches query fingerprints
against the database using time-aligned voting.
"""
import numpy as np
from collections import defaultdict, Counter
from typing import List, Tuple, Dict, Optional
import config


class MatchingEngine:
    """
    Audio fingerprint matching engine using time-offset voting.

    Algorithm:
    1. Generate query fingerprints
    2. Look up each hash in the database
    3. For each match, compute time offset difference (delta)
    4. Vote for (song_id, delta) pairs
    5. Song with most votes is the best match
    6. Verify with MFCC cosine similarity for confidence scoring
    """

    def __init__(self, database, fingerprint_gen, processor):
        self.db = database
        self.fingerprint_gen = fingerprint_gen
        self.processor = processor

    def identify(self, query_fingerprints: List[Tuple[int, int]], 
                 query_features: Optional[Dict] = None,
                 top_k: int = 3) -> List[Dict]:
        """
        Identify a song from query fingerprints.

        Args:
            query_fingerprints: List of (hash, time_offset) from query
            query_features: Optional feature vector for verification
            top_k: Number of top matches to return

        Returns:
            List of match dictionaries with song info and confidence scores
        """
        if not query_fingerprints:
            return []

        # Extract just the hash values for database lookup
        hashes = [h for h, _ in query_fingerprints]

        # Batch lookup all hashes
        matches = self.db.lookup_hashes(hashes)

        if not matches:
            return []

        # Build a map from hash to query time offsets
        query_time_map = defaultdict(list)
        for h, t in query_fingerprints:
            query_time_map[h].append(t)

        # Vote on (song_id, time_delta) pairs
        # time_delta = db_time_offset - query_time_offset
        # If the same song matches at the correct alignment, 
        # time_delta should be consistent across many hashes
        votes = defaultdict(list)

        for hash_val, song_id, db_time in matches:
            for query_time in query_time_map[hash_val]:
                delta = db_time - query_time
                votes[(song_id, delta)].append(1)

        if not votes:
            return []

        # Count votes per (song_id, delta)
        vote_counts = Counter()
        for key, vote_list in votes.items():
            vote_counts[key] = len(vote_list)

        # Aggregate by song (sum votes across all deltas)
        song_scores = Counter()
        song_deltas = defaultdict(list)

        for (song_id, delta), count in vote_counts.most_common():
            song_scores[song_id] += count
            song_deltas[song_id].append((delta, count))

        # Get top candidates
        top_songs = song_scores.most_common(top_k * 2)  # Get extra for verification

        results = []
        for song_id, raw_score in top_songs[:top_k]:
            song = self.db.get_song_by_id(song_id)
            if not song:
                continue

            # Calculate confidence percentage
            max_possible = len(query_fingerprints)
            confidence = min(100, (raw_score / max(config.MATCH_THRESHOLD, max_possible * 0.05)) * 100)
            confidence = min(confidence, 100.0)

            # If query features available, verify with MFCC similarity
            mfcc_similarity = 0.0
            if query_features and song.get('features'):
                mfcc_similarity = self._compute_feature_similarity(
                    query_features, song['features']
                )
                # Combine fingerprint score with feature similarity
                confidence = 0.6 * confidence + 0.4 * mfcc_similarity

            results.append({
                'song_id': song_id,
                'title': song['title'],
                'artist': song['artist'],
                'filepath': song['filepath'],
                'duration': song['duration'],
                'tempo': song['tempo'],
                'confidence': round(confidence, 2),
                'match_score': raw_score,
                'mfcc_similarity': round(mfcc_similarity, 2) if mfcc_similarity else None
            })

        # Sort by combined confidence
        results.sort(key=lambda x: x['confidence'], reverse=True)
        return results

    def _compute_feature_similarity(self, feat1: Dict, feat2: Dict) -> float:
        """
        Compute cosine similarity between two feature vectors.
        Returns value between 0 and 100.
        """
        try:
            # Combine MFCC and chroma means into a single vector
            v1 = np.concatenate([
                feat1.get('mfcc_mean', []),
                feat1.get('chroma_mean', []) * config.FEATURE_WEIGHT_CHROMA / config.FEATURE_WEIGHT_MFCC
            ])
            v2 = np.concatenate([
                feat2.get('mfcc_mean', []),
                feat2.get('chroma_mean', []) * config.FEATURE_WEIGHT_CHROMA / config.FEATURE_WEIGHT_MFCC
            ])

            if len(v1) == 0 or len(v2) == 0:
                return 0.0

            # Cosine similarity
            dot = np.dot(v1, v2)
            norm1 = np.linalg.norm(v1)
            norm2 = np.linalg.norm(v2)

            if norm1 == 0 or norm2 == 0:
                return 0.0

            similarity = dot / (norm1 * norm2)
            # Scale to 0-100
            return max(0, similarity * 100)
        except Exception:
            return 0.0
