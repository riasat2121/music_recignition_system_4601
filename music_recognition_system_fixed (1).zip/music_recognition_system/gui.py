"""
Graphical User Interface Module
Tkinter-based GUI for the Music Recognition System.
Provides tabs for library management, audio identification, and results display.
"""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import threading
import os
import time
from typing import Optional

import config
from audio_processor import AudioProcessor
from fingerprint import FingerprintGenerator, QueryFingerprinter
from database import SongDatabase
from matcher import MatchingEngine
from recommender import RecommendationEngine
from recorder import AudioRecorder
from downloader import YouTubeDownloader


class MusicRecognitionGUI:
    """
    Main GUI application for the Music Recognition System.

    Features:
    - Library Management: Add local files or download from YouTube
    - Audio Identification: Record from microphone or upload audio file
    - Results Display: Show identified song with confidence and recommendations
    """

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Real-Time Audio Pattern Recognition System")
        self.root.geometry("900x700")
        self.root.minsize(800, 600)

        # Initialize core components
        self.processor = AudioProcessor()
        self.fingerprint_gen = FingerprintGenerator()
        self.query_fp = QueryFingerprinter(self.processor, self.fingerprint_gen)
        self.db = SongDatabase()
        self.matcher = MatchingEngine(self.db, self.fingerprint_gen, self.processor)
        self.recommender = RecommendationEngine(self.db)
        self.recorder = AudioRecorder()
        self.downloader = YouTubeDownloader()

        # Status variables
        self.is_recording = False
        self.is_processing = False

        self._setup_styles()
        self._build_ui()
        self._refresh_library()

    def _setup_styles(self):
        """Configure ttk styles for a modern look."""
        style = ttk.Style()
        style.theme_use('clam')

        # Custom colors
        self.colors = {
            'primary': '#2196F3',
            'success': '#4CAF50',
            'warning': '#FF9800',
            'danger': '#f44336',
            'bg': '#f5f5f5',
            'card': '#ffffff'
        }

        style.configure('Title.TLabel', font=('Helvetica', 16, 'bold'))
        style.configure('Subtitle.TLabel', font=('Helvetica', 12))
        style.configure('Card.TFrame', background=self.colors['card'])
        style.configure('Action.TButton', font=('Helvetica', 11, 'bold'))

    def _build_ui(self):
        """Build the main user interface."""
        # Main container
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky="nsew")

        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(1, weight=1)

        # Header
        header = ttk.Label(main_frame, text="🎵 Audio Pattern Recognition System", 
                          style='Title.TLabel')
        header.grid(row=0, column=0, pady=(0, 10), sticky="w")

        # Notebook (tabs)
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.grid(row=1, column=0, sticky="nsew", pady=5)

        # Create tabs
        self._build_library_tab()
        self._build_identify_tab()
        self._build_results_tab()

        # Status bar
        self.status_var = tk.StringVar(value="Ready")
        status_bar = ttk.Label(main_frame, textvariable=self.status_var, 
                              relief=tk.SUNKEN, anchor=tk.W)
        status_bar.grid(row=2, column=0, sticky="ew", pady=(5, 0))

    def _build_library_tab(self):
        """Build the Library Management tab."""
        tab = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(tab, text="📚 Library")

        tab.columnconfigure(0, weight=1)
        tab.rowconfigure(1, weight=1)

        # Controls frame
        controls = ttk.LabelFrame(tab, text="Add Songs", padding="10")
        controls.grid(row=0, column=0, sticky="ew", pady=(0, 10))

        ttk.Button(controls, text="Add Local Files", 
                  command=self._add_local_files).grid(row=0, column=0, padx=5)

        ttk.Button(controls, text="Download from YouTube Playlist", 
                  command=self._show_download_dialog).grid(row=0, column=1, padx=5)

        ttk.Button(controls, text="Clear Database", 
                  command=self._clear_database).grid(row=0, column=2, padx=5)

        # Stats label
        self.stats_label = ttk.Label(controls, text="Songs indexed: 0")
        self.stats_label.grid(row=0, column=3, padx=(20, 5))

        # Song list
        list_frame = ttk.LabelFrame(tab, text="Indexed Songs", padding="5")
        list_frame.grid(row=1, column=0, sticky="nsew")
        list_frame.columnconfigure(0, weight=1)
        list_frame.rowconfigure(0, weight=1)

        # Treeview for songs
        columns = ('title', 'artist', 'duration', 'filepath')
        self.song_tree = ttk.Treeview(list_frame, columns=columns, 
                                     show='headings', height=15)

        self.song_tree.heading('title', text='Title')
        self.song_tree.heading('artist', text='Artist')
        self.song_tree.heading('duration', text='Duration (s)')
        self.song_tree.heading('filepath', text='File Path')

        self.song_tree.column('title', width=250)
        self.song_tree.column('artist', width=150)
        self.song_tree.column('duration', width=80)
        self.song_tree.column('filepath', width=300)

        # Scrollbar
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, 
                                command=self.song_tree.yview)
        self.song_tree.configure(yscrollcommand=scrollbar.set)

        self.song_tree.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")

    def _build_identify_tab(self):
        """Build the Audio Identification tab."""
        tab = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(tab, text="🎤 Identify")

        tab.columnconfigure(0, weight=1)
        tab.rowconfigure(1, weight=1)

        # Input section
        input_frame = ttk.LabelFrame(tab, text="Query Input", padding="15")
        input_frame.grid(row=0, column=0, sticky="ew", pady=(0, 10))

        # Record button
        self.record_btn = ttk.Button(input_frame, text="🔴 Record from Microphone", 
                                    command=self._toggle_record, 
                                    style='Action.TButton')
        self.record_btn.grid(row=0, column=0, padx=5, pady=5)

        # Upload button
        ttk.Button(input_frame, text="📁 Upload Audio File", 
                  command=self._upload_file).grid(row=0, column=1, padx=5, pady=5)

        # Duration spinbox
        ttk.Label(input_frame, text="Duration (s):").grid(row=0, column=2, padx=(20, 5))
        self.duration_var = tk.IntVar(value=10)
        ttk.Spinbox(input_frame, from_=3, to=30, textvariable=self.duration_var, 
                   width=5).grid(row=0, column=3, padx=5)

        # Results section
        results_frame = ttk.LabelFrame(tab, text="Identification Results", padding="10")
        results_frame.grid(row=1, column=0, sticky="nsew")
        results_frame.columnconfigure(0, weight=1)
        results_frame.rowconfigure(1, weight=1)

        # Top match display
        self.match_frame = ttk.Frame(results_frame)
        self.match_frame.grid(row=0, column=0, sticky="ew", pady=(0, 10))

        self.match_title = ttk.Label(self.match_frame, text="No match yet", 
                                  font=('Helvetica', 14, 'bold'))
        self.match_title.grid(row=0, column=0, sticky="w")

        self.match_artist = ttk.Label(self.match_frame, text="", 
                                     font=('Helvetica', 11))
        self.match_artist.grid(row=1, column=0, sticky="w")

        self.match_confidence = ttk.Label(self.match_frame, text="", 
                                         font=('Helvetica', 11))
        self.match_confidence.grid(row=2, column=0, sticky="w")

        # Alternative matches
        ttk.Label(results_frame, text="Alternative Matches:", 
                 font=('Helvetica', 11, 'bold')).grid(row=1, column=0, sticky="w")

        self.alt_list = tk.Listbox(results_frame, height=6, font=('Helvetica', 10))
        self.alt_list.grid(row=2, column=0, sticky="nsew", pady=(5, 0))

    def _build_results_tab(self):
        """Build the Recommendations tab."""
        tab = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(tab, text="🎶 Recommendations")

        tab.columnconfigure(0, weight=1)
        tab.rowconfigure(1, weight=1)

        # Current song info
        info_frame = ttk.LabelFrame(tab, text="Currently Identified Song", padding="10")
        info_frame.grid(row=0, column=0, sticky="ew", pady=(0, 10))

        self.rec_title = ttk.Label(info_frame, text="None", 
                                  font=('Helvetica', 13, 'bold'))
        self.rec_title.grid(row=0, column=0, sticky="w")

        # Recommendations list
        rec_frame = ttk.LabelFrame(tab, text="Similar Songs", padding="5")
        rec_frame.grid(row=1, column=0, sticky="nsew")
        rec_frame.columnconfigure(0, weight=1)
        rec_frame.rowconfigure(0, weight=1)

        columns = ('title', 'artist', 'similarity')
        self.rec_tree = ttk.Treeview(rec_frame, columns=columns, 
                                    show='headings', height=15)

        self.rec_tree.heading('title', text='Title')
        self.rec_tree.heading('artist', text='Artist')
        self.rec_tree.heading('similarity', text='Similarity %')

        self.rec_tree.column('title', width=350)
        self.rec_tree.column('artist', width=250)
        self.rec_tree.column('similarity', width=100)

        scrollbar = ttk.Scrollbar(rec_frame, orient=tk.VERTICAL, 
                                command=self.rec_tree.yview)
        self.rec_tree.configure(yscrollcommand=scrollbar.set)

        self.rec_tree.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")

    def _add_local_files(self):
        """Add local audio files to the database."""
        files = filedialog.askopenfilenames(
            title="Select Audio Files",
            filetypes=[("Audio files", "*.wav *.mp3 *.flac *.m4a *.ogg *.webm"), 
                      ("All files", "*.*")]
        )
        if not files:
            return

        self.status_var.set(f"Processing {len(files)} files...")
        self.root.update()

        processed = 0
        for filepath in files:
            try:
                self._index_song(filepath)
                processed += 1
            except Exception as e:
                print(f"Error processing {filepath}: {e}")

        self._refresh_library()
        self.status_var.set(f"Added {processed} songs to database")
        messagebox.showinfo("Complete", f"Successfully indexed {processed} songs.")

    def _index_song(self, filepath: str):
        """Process and index a single song file."""
        # Load the FULL song (up to config.DB_INDEX_MAX_DURATION), not the
        # short query duration - otherwise only the first ~30s of every
        # song gets fingerprinted, and any recording from later in the
        # track can never match since those fingerprints don't exist.
        y, sr = self.processor.load_audio(filepath, duration=config.DB_INDEX_MAX_DURATION)

        # Extract features
        features = self.processor.get_feature_vector(y)
        tempo = features['tempo']

        # Generate fingerprints
        peaks = self.processor.get_spectral_peaks(y)
        fingerprints = self.fingerprint_gen.generate_fingerprints(peaks)

        # Parse filename for metadata
        basename = os.path.splitext(os.path.basename(filepath))[0]
        parts = basename.split(' - ', 1)
        if len(parts) == 2:
            artist, title = parts
        else:
            artist = "Unknown"
            title = basename

        duration = float(len(y)) / float(sr)

        # Add to database
        self.db.add_song(title, artist, filepath, duration, tempo, 
                        features, fingerprints)

    def _show_download_dialog(self):
        """Show dialog for YouTube playlist download."""
        dialog = tk.Toplevel(self.root)
        dialog.title("Download from YouTube")
        dialog.geometry("500x200")
        dialog.transient(self.root)

        ttk.Label(dialog, text="YouTube Playlist URL:").pack(pady=(20, 5))
        url_var = tk.StringVar()
        ttk.Entry(dialog, textvariable=url_var, width=50).pack(padx=20)

        ttk.Label(dialog, text="Max songs (optional):").pack(pady=(10, 5))
        max_var = tk.IntVar(value=10)
        ttk.Spinbox(dialog, from_=1, to=100, textvariable=max_var, width=10).pack()

        def do_download():
            url = url_var.get().strip()
            if not url:
                messagebox.showwarning("Error", "Please enter a URL")
                return

            dialog.destroy()
            self._download_playlist(url, max_var.get())

        ttk.Button(dialog, text="Download", command=do_download).pack(pady=20)

    def _download_playlist(self, url: str, max_songs: int):
        """Download and index a YouTube playlist."""
        if not self.downloader.is_available():
            messagebox.showerror("Error", "yt-dlp not installed.\nInstall with: pip install yt-dlp")
            return

        self.status_var.set("Downloading playlist...")
        self.root.update()

        def progress_hook(info):
            self.status_var.set(f"Downloaded: {info.get('title', '...')}")
            self.root.update()

        try:
            songs = self.downloader.download_playlist(url, progress_hook, max_songs)

            for song in songs:
                try:
                    self._index_song(song['filepath'])
                except Exception as e:
                    print(f"Error indexing {song['title']}: {e}")

            self._refresh_library()
            self.status_var.set(f"Downloaded and indexed {len(songs)} songs")
            messagebox.showinfo("Complete", f"Added {len(songs)} songs from playlist.")

        except Exception as e:
            messagebox.showerror("Error", f"Download failed: {e}")
            self.status_var.set("Ready")

    def _clear_database(self):
        """Clear all songs from database."""
        if messagebox.askyesno("Confirm", "Delete all indexed songs?"):
            self.db.clear_database()
            self._refresh_library()
            self.status_var.set("Database cleared")

    def _refresh_library(self):
        """Refresh the song list display."""
        # Clear tree
        for item in self.song_tree.get_children():
            self.song_tree.delete(item)

        # Load songs
        songs = self.db.get_all_songs()
        for song in songs:
            self.song_tree.insert('', tk.END, values=(
                song['title'],
                song['artist'],
                f"{song['duration']:.1f}",
                song['filepath']
            ))

        self.stats_label.config(text=f"Songs indexed: {len(songs)}")

    def _toggle_record(self):
        """Toggle microphone recording."""
        if self.is_recording:
            return  # Handled by timer

        if not self.recorder.is_available():
            messagebox.showerror("Error", "sounddevice not installed.\nInstall with: pip install sounddevice")
            return

        duration = self.duration_var.get()
        self.is_recording = True
        self.record_btn.config(text="⏹ Recording...")
        self.status_var.set(f"Recording for {duration} seconds...")
        self.root.update()

        # Record in background thread
        def record_task():
            try:
                filepath = self.recorder.record(duration=duration)
                self.root.after(0, lambda: self._process_query(filepath))
            except Exception as e:
                self.root.after(0, lambda: messagebox.showerror("Error", str(e)))
            finally:
                self.is_recording = False
                self.root.after(0, lambda: self.record_btn.config(
                    text="🔴 Record from Microphone"))

        thread = threading.Thread(target=record_task)
        thread.daemon = True
        thread.start()

    def _upload_file(self):
        """Upload and identify an audio file."""
        filepath = filedialog.askopenfilename(
            title="Select Audio File",
            filetypes=[("Audio files", "*.wav *.mp3 *.flac *.m4a *.ogg *.webm"), 
                      ("All files", "*.*")]
        )
        if filepath:
            self._process_query(filepath)

    def _process_query(self, filepath: str):
        """Process query audio and display results."""
        self.status_var.set("Analyzing audio...")
        self.root.update()

        try:
            # Generate fingerprints and features (with noise reduction for microphone input)
            query_fingerprints, y = self.query_fp.fingerprint_audio(filepath, preprocess=True)
            query_features = self.processor.get_feature_vector(y)

            if not query_fingerprints:
                messagebox.showwarning("Warning", "No fingerprints generated. "
                                      "Audio may be too quiet or noisy.")
                self.status_var.set("Ready")
                return

            # Match
            self.status_var.set("Matching against database...")
            self.root.update()

            results = self.matcher.identify(query_fingerprints, query_features, top_k=5)

            if not results:
                self.match_title.config(text="No match found")
                self.match_artist.config(text="Try recording more clearly or adding the song to library.")
                self.match_confidence.config(text="")
                self.alt_list.delete(0, tk.END)
                self.status_var.set("No match found")
                return

            # Display top match
            top = results[0]
            self.match_title.config(text=f"🎵 {top['title']}")
            self.match_artist.config(text=f"👤 {top['artist']}")
            self.match_confidence.config(
                text=f"Confidence: {top['confidence']}% | Match Score: {top['match_score']}"
            )

            # Update recommendations tab
            self.rec_title.config(text=f"{top['title']} by {top['artist']}")

            # Get recommendations
            recommendations = self.recommender.get_recommendations(top['song_id'])

            # Clear and populate alternatives
            self.alt_list.delete(0, tk.END)
            for i, r in enumerate(results[1:], 1):
                self.alt_list.insert(tk.END, 
                    f"{i}. {r['title']} by {r['artist']} ({r['confidence']}%)")

            # Clear and populate recommendations tree
            for item in self.rec_tree.get_children():
                self.rec_tree.delete(item)

            for rec in recommendations:
                self.rec_tree.insert('', tk.END, values=(
                    rec['title'],
                    rec['artist'],
                    f"{rec['similarity_score']}%"
                ))

            # Switch to results tab
            self.notebook.select(1)  # Identify tab
            self.status_var.set(f"Identified: {top['title']}")

        except Exception as e:
            messagebox.showerror("Error", f"Identification failed: {e}")
            self.status_var.set("Error during identification")


def main():
    """Launch the GUI application."""
    root = tk.Tk()
    app = MusicRecognitionGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
