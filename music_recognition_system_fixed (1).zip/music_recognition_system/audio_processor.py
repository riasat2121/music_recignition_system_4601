"""
Audio Processor Module
Handles loading, pre-processing, and feature extraction from audio files.
Extracts spectrograms, MFCCs, chroma features, and spectral peaks for fingerprinting.
"""
import os
import numpy as np
import librosa
from scipy.ndimage import maximum_filter, uniform_filter1d
from scipy.signal import butter, filtfilt
import config


class AudioProcessor:
    """
    Core audio processing class for feature extraction.

    Attributes:
        sr (int): Sample rate
        duration (float): Analysis duration in seconds
        n_fft (int): FFT window size
        hop_length (int): Hop length for STFT
    """

    def __init__(self, sr=config.SAMPLE_RATE, duration=config.ANALYZE_DURATION,
                 n_fft=config.N_FFT, hop_length=config.HOP_LENGTH):
        self.sr = sr
        self.duration = duration
        self.n_fft = n_fft
        self.hop_length = hop_length

    def load_audio(self, filepath: str, duration: float = None) -> tuple[np.ndarray, int]:
        """
        Load audio file and resample to target sample rate.
        Supports WAV, MP3, FLAC, M4A, OGG, and WebM (via ffmpeg fallback).

        Args:
            filepath: Path to audio file
            duration: Max seconds to load. Defaults to self.duration (short,
                meant for query clips). Library indexing should pass a much
                larger value (e.g. config.DB_INDEX_MAX_DURATION) so the
                *whole* song gets fingerprinted - otherwise anything
                recorded past that cutoff can never match, since those
                fingerprints were never stored.

        Returns:
            Tuple of (audio_time_series, sample_rate)
        """
        load_duration = duration if duration is not None else self.duration
        try:
            y, sr = librosa.load(
                filepath,
                sr=self.sr,
                duration=load_duration,
                mono=True
            )
            # Extra safety: librosa may return 2D on some formats
            y = self._to_mono(y)
            return y, sr
        except Exception as e:
            # Fallback to ffmpeg for any format librosa/soundfile can't read
            # directly (M4A/AAC, WebM, OGG-Opus variants, etc).
            #
            # NOTE: this used to only trigger for filenames ending in ".webm"
            # or when "soundfile" literally appeared in the error text. That
            # missed M4A entirely: soundfile raises
            # `soundfile.LibsndfileError: Error opening '...': Format not
            # recognised.` - the *message* doesn't contain the word
            # "soundfile", so M4A recordings (a very common phone recording
            # format) always fell through to the raise below instead of ever
            # reaching ffmpeg. Now we just always try ffmpeg as a fallback,
            # since it's a safe no-op cost if it also fails.
            try:
                y, sr = self._load_with_ffmpeg(filepath, duration=load_duration)
                return y, sr
            except Exception as ffmpeg_err:
                raise RuntimeError(
                    f"Failed to load audio {filepath}. "
                    f"librosa error: {e}. "
                    f"ffmpeg fallback error: {ffmpeg_err}. "
                    f"Ensure ffmpeg is installed and in PATH."
                )

    def _load_with_ffmpeg(self, filepath: str, duration: float = None) -> tuple[np.ndarray, int]:
        """
        Fallback audio loader using ffmpeg via temporary WAV conversion.
        Handles WebM, M4A, and other formats not supported by soundfile.
        """
        import tempfile
        import subprocess

        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            tmp_path = tmp.name

        try:
            # Convert to WAV using ffmpeg
            cmd = ["ffmpeg", "-y", "-i", filepath, "-ar", str(self.sr), "-ac", "1"]
            # NOTE: this previously always used self.duration (30s) here
            # regardless of what load_audio() was actually asked for, so
            # even after fixing the duration cap elsewhere, any file that
            # needed the ffmpeg fallback (M4A, WebM, etc.) would silently
            # get truncated back down to 30s during library indexing.
            if duration:
                cmd += ["-t", str(duration)]
            cmd += ["-f", "wav", tmp_path]
            subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

            # Load the converted WAV
            y, sr = librosa.load(tmp_path, sr=self.sr, mono=True)
            return y, sr
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)

    def get_spectrogram(self, y: np.ndarray) -> np.ndarray:
        """
        Compute magnitude spectrogram using STFT.

        Args:
            y: Audio time series

        Returns:
            Magnitude spectrogram array (freq_bins x time_frames)
        """
        return np.abs(librosa.stft(y, n_fft=self.n_fft, hop_length=self.hop_length))

    def get_log_spectrogram(self, y: np.ndarray) -> np.ndarray:
        """
        Compute log-scaled spectrogram for visualization and peak detection.

        Args:
            y: Audio time series

        Returns:
            Log-scaled spectrogram in dB
        """
        spec = self.get_spectrogram(y)
        return librosa.amplitude_to_db(spec, ref=np.max)

    def get_mfcc(self, y: np.ndarray) -> np.ndarray:
        """
        Extract Mel-Frequency Cepstral Coefficients (MFCCs).
        MFCCs capture the timbral texture of the audio and are robust
        to minor pitch and tempo variations.

        Args:
            y: Audio time series

        Returns:
            MFCC matrix (n_mfcc x time_frames)
        """
        return librosa.feature.mfcc(
            y=y,
            sr=self.sr,
            n_mfcc=config.N_MFCC,
            n_fft=self.n_fft,
            hop_length=self.hop_length
        )

    def get_chroma(self, y: np.ndarray) -> np.ndarray:
        """
        Extract chroma features representing the 12 pitch classes.
        Useful for harmonic and melodic similarity.

        Args:
            y: Audio time series

        Returns:
            Chroma feature matrix (12 x time_frames)
        """
        return librosa.feature.chroma_stft(
            y=y,
            sr=self.sr,
            n_fft=self.n_fft,
            hop_length=self.hop_length
        )

    def get_tempo(self, y: np.ndarray) -> float:
        """
        Estimate the tempo (BPM) of the audio.

        Args:
            y: Audio time series

        Returns:
            Estimated tempo in beats per minute (native Python float)
        """
        onset_env = librosa.onset.onset_strength(y=y, sr=self.sr)
        tempo, _ = librosa.beat.beat_track(onset_envelope=onset_env, sr=self.sr)
        # librosa may return a numpy scalar; SQLite requires native Python types
        if hasattr(tempo, 'item'):
            return float(tempo.item())
        return float(tempo)

    # ========================
    # NOISE REDUCTION PIPELINE
    # ========================

    def preprocess_query(self, y: np.ndarray) -> np.ndarray:
        """
        Preprocessing pipeline for microphone/query audio before fingerprinting.

        IMPORTANT: this fingerprinting algorithm picks a single "winner" peak
        per time-frequency neighborhood (a hard, winner-take-all decision).
        Any filtering applied *before* peak detection - even something as
        mild as a highpass filter or spectral gate - can shift relative
        amplitudes enough to flip which bin wins, which silently changes the
        fingerprint hash and breaks matching. Testing confirmed the highpass
        filter and spectral gate were doing more damage to match rates than
        the noise they removed was doing, even on very lightly degraded
        audio. So this pipeline is intentionally conservative: normalize and
        trim silence (which don't reshape the spectrum) are safe and kept;
        the highpass/pre-emphasis/spectral-gate steps are skipped by default
        and only kept as opt-in below for cases with heavy, obvious hum/rumble.

        Args:
            y: Raw audio time series from microphone or noisy source

        Returns:
            Cleaned audio ready for fingerprinting
        """
        if config.QUERY_APPLY_SPECTRAL_FILTERS:
            y = self._highpass_filter(y, cutoff=config.QUERY_HIGHPASS_CUTOFF)
            y = self._preemphasis(y, coeff=config.QUERY_PREEMPHASIS)
            y = self._spectral_gate(y, threshold_mult=config.QUERY_NOISE_GATE_THRESHOLD)
        if config.QUERY_NORMALIZE:
            y = self._normalize(y)
        if config.QUERY_TRIM_SILENCE:
            y = self._trim_silence(y)
        # Final mono safety check
        y = self._to_mono(y)
        return y

    def _highpass_filter(self, y: np.ndarray, cutoff: float = 80.0, order: int = 4) -> np.ndarray:
        """
        Butterworth high-pass filter to remove rumble, hum, and wind noise.

        Uses filtfilt (zero-phase, forward-backward filtering) instead of
        lfilter. lfilter introduces group delay that smears transients in
        time - for fingerprint matching that shifts exactly the spectral
        peaks the whole algorithm depends on, which was enough to break
        matching even on a completely clean, unaltered clip.
        """
        nyquist = self.sr / 2.0
        normalized_cutoff = cutoff / nyquist
        if normalized_cutoff >= 1.0:
            return y
        b, a = butter(order, normalized_cutoff, btype='high', analog=False)
        return filtfilt(b, a, y)

    def _preemphasis(self, y: np.ndarray, coeff: float = 0.97) -> np.ndarray:
        """Boost high frequencies to compensate for microphone rolloff and improve peak clarity."""
        return np.append(y[0], y[1:] - coeff * y[:-1])

    def _spectral_gate(self, y: np.ndarray, threshold_mult: float = 0.01) -> np.ndarray:
        """
        Spectral gating noise reduction.
        Estimates noise from the quietest frames and subtracts it from the spectrum.
        """
        # Compute STFT
        stft_matrix = librosa.stft(y, n_fft=self.n_fft, hop_length=self.hop_length)
        magnitude = np.abs(stft_matrix)
        phase = np.angle(stft_matrix)

        # Estimate noise profile from the quietest 10% of frames
        frame_energies = np.mean(magnitude, axis=0)
        n_noise_frames = max(1, int(len(frame_energies) * 0.1))
        noise_frames_idx = np.argsort(frame_energies)[:n_noise_frames]
        noise_profile = np.mean(magnitude[:, noise_frames_idx], axis=1, keepdims=True)

        # Subtract noise profile with threshold
        mask = magnitude > (threshold_mult * noise_profile)
        cleaned_magnitude = magnitude * mask

        # Reconstruct signal
        cleaned_stft = cleaned_magnitude * np.exp(1j * phase)
        y_cleaned = librosa.istft(cleaned_stft, hop_length=self.hop_length, length=len(y))
        return y_cleaned

    def _normalize(self, y: np.ndarray, target_db: float = -1.0) -> np.ndarray:
        """Peak normalize audio to target dB to ensure consistent levels."""
        peak = np.max(np.abs(y))
        if peak > 1e-10:
            target_linear = 10 ** (target_db / 20.0)
            y = y * (target_linear / peak)
        return y

    def _trim_silence(self, y: np.ndarray, top_db: float = 20.0) -> np.ndarray:
        """Trim leading and trailing silence using librosa."""
        yt, _ = librosa.effects.trim(y, top_db=top_db)
        return yt

    def _to_mono(self, y: np.ndarray) -> np.ndarray:
        """
        Convert multi-channel audio to mono.
        Handles both (channels, samples) and (samples, channels) layouts.
        Windows microphones often record stereo (2 channels).
        """
        if y.ndim == 1:
            return y
        elif y.ndim == 2:
            # Determine if channels are rows or columns
            if y.shape[0] <= 4:  # Likely (channels, samples)
                return np.mean(y, axis=0)
            else:  # Likely (samples, channels)
                return np.mean(y, axis=1)
        else:
            return np.mean(y, axis=tuple(range(y.ndim - 1)))

    def get_spectral_peaks(self, y: np.ndarray,
                          n_peaks: int = None,
                          query_mode: bool = False) -> np.ndarray:
        """
        Detect robust spectral peaks in the time-frequency representation.
        Uses 2D maximum filtering to find local maxima, then filters by
        amplitude threshold.

        This is the foundation of the audio fingerprinting algorithm.

        Args:
            y: Audio time series
            n_peaks: Maximum number of peaks to return. If None (default),
                it's computed automatically from the audio's duration and a
                target peak density (see config.PEAK_TARGET_DENSITY_PER_SEC /
                QUERY_PEAK_TARGET_DENSITY_PER_SEC), capped by TOP_N_PEAKS /
                QUERY_TOP_N_PEAKS. Pass an explicit value to override.
            query_mode: Use query-tuned density/threshold/ceiling instead of
                the library (DB) ones.

        Returns:
            Array of peak coordinates [freq_bin, time_frame]
        """
        # Use query-specific parameters for noisy microphone input
        if query_mode:
            density_per_sec = config.QUERY_PEAK_TARGET_DENSITY_PER_SEC
            ceiling = config.QUERY_TOP_N_PEAKS
            percentile = config.QUERY_PEAK_AMP_PERCENTILE
        else:
            density_per_sec = config.PEAK_TARGET_DENSITY_PER_SEC
            ceiling = config.TOP_N_PEAKS
            percentile = config.PEAK_AMP_PERCENTILE

        # Compute log spectrogram for better dynamic range
        spec = self.get_log_spectrogram(y)
        total_frames = spec.shape[1]
        duration_sec = total_frames * self.hop_length / float(self.sr)

        if n_peaks is None:
            # Budget peaks proportionally to duration instead of one fixed
            # constant. A fixed cap (e.g. 2500) badly under-fingerprints a
            # multi-minute song relative to a 30s clip.
            n_peaks = min(ceiling, max(1, int(density_per_sec * duration_sec)))

        # Light smoothing along the frequency axis before peak-picking.
        # Peak detection is winner-take-all: with a raw spectrogram, tiny
        # amplitude perturbations (mic noise, encoding artifacts) can flip
        # which of two closely-matched neighboring bins gets picked as
        # "the" peak, silently changing the fingerprint hash. Smoothing
        # stabilizes which bin wins without noticeably moving true peaks.
        spec_for_peaks = uniform_filter1d(spec, size=3, axis=0)

        # Apply 2D maximum filter to find local maxima
        local_max = maximum_filter(spec_for_peaks, size=config.PEAK_NEIGHBORHOOD_SIZE) == spec_for_peaks

        # Amplitude threshold based on percentile
        amp_threshold = np.percentile(spec_for_peaks, percentile)

        # Mask for significant peaks
        detected_peaks = local_max & (spec_for_peaks > amp_threshold)

        # Extract coordinates
        freq_idx, time_idx = np.where(detected_peaks)
        amplitudes = spec_for_peaks[freq_idx, time_idx]

        if len(amplitudes) > n_peaks:
            freq_idx, time_idx = self._select_peaks_with_time_coverage(
                freq_idx, time_idx, amplitudes, n_peaks, total_frames
            )

        # Return as [freq_bin, time_frame] array
        peaks = np.column_stack((freq_idx, time_idx))
        return peaks

    def _select_peaks_with_time_coverage(self, freq_idx, time_idx, amplitudes,
                                          n_peaks, total_frames, n_windows=40):
        """
        Cap the number of peaks down to n_peaks while keeping coverage
        spread across the whole duration.

        A plain global "take the N loudest peaks" concentrates almost all
        selected peaks in the loudest section of a song (e.g. the chorus or
        a drop), leaving quieter sections - verses, bridges, intros/outros -
        with few or no fingerprints at all. Anyone recording from one of
        those under-covered sections then fails to match even though the
        song IS indexed. Splitting the timeline into windows and taking the
        top peaks *within each window* guarantees every part of the song
        gets a baseline share of fingerprints; the loudest sections still
        get to keep any leftover budget.
        """
        if len(amplitudes) <= n_peaks:
            return freq_idx, time_idx

        window_size = max(1, total_frames // n_windows)
        window_of = np.minimum(time_idx // window_size, n_windows - 1)
        per_window_budget = max(1, n_peaks // n_windows)

        selected = []
        for w in range(n_windows):
            mask = window_of == w
            if not np.any(mask):
                continue
            idxs = np.where(mask)[0]
            amps_w = amplitudes[idxs]
            take = min(per_window_budget, len(idxs))
            top_local = idxs[np.argsort(amps_w)[::-1][:take]]
            selected.append(top_local)

        selected_idx = np.concatenate(selected) if selected else np.array([], dtype=int)

        # Fill any remaining budget with the next-loudest peaks overall
        remaining = n_peaks - len(selected_idx)
        if remaining > 0:
            leftover_mask = np.ones(len(amplitudes), dtype=bool)
            leftover_mask[selected_idx] = False
            leftover_idx = np.where(leftover_mask)[0]
            if len(leftover_idx) > 0:
                leftover_amps = amplitudes[leftover_idx]
                extra = leftover_idx[np.argsort(leftover_amps)[::-1][:remaining]]
                selected_idx = np.concatenate([selected_idx, extra])

        return freq_idx[selected_idx], time_idx[selected_idx]

    def get_feature_vector(self, y: np.ndarray) -> dict:
        """
        Extract a comprehensive feature vector for a song.
        Used for recommendation and verification.

        Args:
            y: Audio time series

        Returns:
            Dictionary containing MFCC mean/std, chroma mean/std, and tempo
        """
        mfcc = self.get_mfcc(y)
        chroma = self.get_chroma(y)
        tempo = self.get_tempo(y)

        # Convert numpy arrays to native Python lists for SQLite compatibility
        features = {
            'mfcc_mean': np.mean(mfcc, axis=1).tolist(),
            'mfcc_std': np.std(mfcc, axis=1).tolist(),
            'chroma_mean': np.mean(chroma, axis=1).tolist(),
            'chroma_std': np.std(chroma, axis=1).tolist(),
            'tempo': tempo
        }
        return features
